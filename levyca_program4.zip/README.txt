Below are the commands to run the line_processor program:

To Compile: gcc --std=c99 -lm -pthread -o line_processor multi_thread.c

To Run: ./line_processor

To Run using input file: ./line_processor < input.txt

To Run and write program input to output file: ./line_processor > output.txt

To Run using input file and then write to output file: ./line_processor < input.txt > output.txt