/*********************
Name: Casey Levy
CS 344 - Assignment 4 -  Multi-threaded Producer/Consumer Pipeline
Description: Creating a program that creates 4 threads to process input
   from standard input and producing output. 

Code referenced/inspired from the following links:
Module 6 - Concurrency and Threading Canvas page
https://replit.com/@cs344/65prodconspipelinec
https://www.youtube.com/watch?v=LgOdgDwwgn4
https://www.classes.cs.uchicago.edu/archive/2018/spring/12300-1/lab6.html

**********************/

#include <pthread.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <string.h>
#include <sys/stat.h>
#include <signal.h>


// Globals
#define SIZE 50
#define SIZE_INPUT 1000

// Variables for Buffer 1
char* buff_1[SIZE];    // buffer 1, shared resource between input thread and line seperator thread
int con_idx_1 = 0;     // Index where sqrt thread will pick up next item
int prod_idx_1 = 0;     // Index where the input thread will put the next item
int count_1 = 0;       // Number of items in buffer
pthread_mutex_t mutex_1 = PTHREAD_MUTEX_INITIALIZER;     // Mutex for buffer 1
pthread_cond_t full_1 = PTHREAD_COND_INITIALIZER;        // Conditiona var for buffer 1

// Variables for Buffer 2
char* buff_2[SIZE];    // buffer 2, shared resource between line seperator thread and reaplce +'s thread
int con_idx_2 = 0;     // Index where sqrt thread will pick up next item
int prod_idx_2 = 0;     // Index where the input thread will put the next item
int count_2 = 0;       // Number of items in buffer
pthread_mutex_t mutex_2 = PTHREAD_MUTEX_INITIALIZER;     // Mutex for buffer 2
pthread_cond_t full_2 = PTHREAD_COND_INITIALIZER;        // Conditiona var for buffer 2

// Variables for Buffer 3
char* buff_3[SIZE];    // buffer 3, shared resource between replace +'s thread and thread for output
int con_idx_3 = 0;     // Index where sqrt thread will pick up next item
int prod_idx_3 = 0;     // Index where the input thread will put the next item
int count_3 = 0;       // Number of items in buffer
pthread_mutex_t mutex_3 = PTHREAD_MUTEX_INITIALIZER;     // Mutex for buffer 3
pthread_cond_t full_3 = PTHREAD_COND_INITIALIZER;        // Conditiona var for buffer 3

// Variables to cooridnate thread 1 and thread 4
int con_idx_4 = 0;     // Index where sqrt thread will pick up next item
int prod_idx_4 = 0;     // Index where the input thread will put the next item
int count_4 = 0;       // Number of items in buffer
pthread_mutex_t mutex_4 = PTHREAD_MUTEX_INITIALIZER;     // Mutex for buffer 4
pthread_cond_t full_4 = PTHREAD_COND_INITIALIZER;        // Conditiona var for buffer 4


/**********

Placing an item into Buffer 1

**********/
void buff_1_put(char* new_item) {
   pthread_mutex_lock(&mutex_1);     // Locking mutex before placing item in buffer
   buff_1[prod_idx_1] = new_item;      // Placing item into buffer
   prod_idx_1 += 1;                  // Incrementing index
   count_1++;

   pthread_cond_signal(&full_1);     // Signalling buffer isn't empty 
   pthread_mutex_unlock(&mutex_1);   // Unlocking mutex
}


/**********

Getting user input

**********/
void* user_input() {
   int end = 0;
   char user_buffer[SIZE_INPUT];
   while (end == 0)
   {
      fgets(user_buffer, SIZE_INPUT, stdin);
      buff_1_put(user_buffer);

      pthread_mutex_lock(&mutex_4);     // Locking and waiting until print thread has processed line
      while(count_4 == 0)
      {
         pthread_cond_wait(&full_4, &mutex_4);
      }

      count_4++;                      // Incrementing count
      pthread_mutex_unlock(&mutex_4);     // Unlocking mutex
      if(!strncmp(user_buffer, "STOP\n", 5))
      {
         end = 1;             // Exiting if we passed on "STOP"
      }
   }

   return NULL;                  // Terminating function

}


/**********

Getting next item in Buffer 1

**********/
char* buff_1_get(){
   pthread_mutex_lock(&mutex_1);     // Locking mutex

   while(count_1 == 0)
   {
      pthread_cond_wait(&full_1, &mutex_1);       // Waiting till the buffer has data to process
   }

   char* new = buff_1[con_idx_1];
   con_idx_1 += 1;
   count_1 --;
   pthread_mutex_unlock(&mutex_1);
   return new;
}


/**********

Placing an item in Buffer 2

**********/
void buff_2_put(char* item) {
   pthread_mutex_lock(&mutex_2);       // Locking the mutex
   buff_2[prod_idx_2] = item;    // Placing item into buffer
   prod_idx_2 += 1;                  // Incrementing index
   count_2++;

   pthread_cond_signal(&full_2);     // Signalling that buffer isn't empty 
   pthread_mutex_unlock(&mutex_2);   // Unlocking mutex
}


/**********

Replacing seperators with a space

**********/
void* seperator_replace(void* args) {
   int end = 0;
   char item[SIZE_INPUT] = "";
   char* new_item;
   while(end == 0) 
   {
      new_item = buff_1_get();
      if(!strncmp(new_item, "STOP\n", 5))
      {
         end = 1;
      }

      else
      {
         new_item[strlen(new_item) - 1] = ' ';
      }

      buff_2_put(new_item);
   }

   return NULL;
}




/**********

Getting next item in Buffer 2

**********/
char* buff_2_get() {
   pthread_mutex_lock(&mutex_2);     // Locking mutex

   while(count_2 == 0)
   {
      pthread_cond_wait(&full_2, &mutex_2);       // Waiting till the buffer has data to process
   }

   char* new = buff_2[con_idx_2];
   con_idx_2 += 1;
   count_2 --;
   pthread_mutex_unlock(&mutex_2);
   return new;
}


/**********

Placing an item in Buffer 3

**********/
void buff_3_put(char* an_item) {
   pthread_mutex_lock(&mutex_3);      // Locking the mutex
   buff_3[prod_idx_3] = an_item;    // Placing item into buffer
   prod_idx_3 += 1;                  // Incrementing index
   count_3++;

   pthread_cond_signal(&full_3);     // Signalling that buffer isn't empty 
   pthread_mutex_unlock(&mutex_3);   // Unlocking mutex
}


/**********

Replacing all "++" symbols with "^"

**********/
void* replace_plus(void* args) {
   int end = 0;
   char *new_item;
   while(end == 0)      // Replace loop
   {
      new_item = buff_2_get();
      if(!strncmp(new_item, "STOP\n", 5))
      {
         end = 1;
      }

      else
      {
         int i = 0;
         int len = strlen(new_item);
         while(i < len) 
         {
            if(new_item[i] == '+' && i < len - 1)
            {
               if(new_item[i+1] == '+')
               {
                  new_item[i] = '^';
                  for(int y=i+1; y < len-1; y++)
                     new_item[y] = new_item[y+1];

                  new_item[len-1] = '\0';
               }
            }

            i++;
         }
      }

      buff_3_put(new_item);
   }
}



/**********

Getting next item in Buffer 3

**********/
char* buff_3_get() {
   pthread_mutex_lock(&mutex_3);     // Locking mutex

   while(count_3 == 0)
   {
      pthread_cond_wait(&full_3, &mutex_3);       // Waiting till the buffer has data to process
   }

   char* new = buff_3[con_idx_3];
   con_idx_3 += 1;
   count_3 --;
   pthread_mutex_unlock(&mutex_3);
   return new;
}


/**********

Function for output thread

**********/
void* print_output(void* args) {
   int x = 0;
   int end = 0;
   char new_line[SIZE_INPUT];
   char* new_item;
   while(end == 0)                // Printing loop
   {
      new_item = buff_3_get();
   

   if(!strncmp(new_item, "STOP\n", 5))
   {
      end = 1;
   }

      else 
      {
         for(int y = 0; y < strlen(new_item); y++)   // Checking length
         {
            new_line[x] = new_item[y];
            x++;

            if(x == 80)
            {
               new_line[x] = '\n';
               new_line[x + 1] = '\0';
               fprintf(stdout, new_line);
               fflush(stdout);               // Flushing buffer

               x = 0;
               new_line[0] = '\0';
            }
         }
      }

      pthread_mutex_lock(&mutex_4);
      count_4 --;

      pthread_cond_signal(&full_4);
      pthread_mutex_unlock(&mutex_4);
      exit(0);

  }

}



/**********

Main Function

**********/
int main(int argc, char* argv[]) {
   srand(time(0));

   pthread_t input_t, line_seperator_t, plus_sign_t, output_t;

   // Creating threads
   pthread_create(&input_t, NULL, user_input, NULL);
   pthread_create(&line_seperator_t, NULL, seperator_replace, NULL);
   pthread_create(&plus_sign_t, NULL, replace_plus, NULL);
   pthread_create(&output_t, NULL, print_output, NULL);

   // Waiting for terminating threads
   pthread_join(input_t, NULL);
   pthread_join(line_seperator_t, NULL);
   pthread_join(plus_sign_t, NULL);
   pthread_join(output_t, NULL);

   return EXIT_SUCCESS;

}