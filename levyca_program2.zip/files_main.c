/*********************************

Name: Casey Levy
Info: CS 344 Assignment 2 - Files and Directories
Program Description: A program to read and write to files on Unix

**********************************/

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>
#include <fcntl.h>
#include <unistd.h>
#include <time.h>
#include <dirent.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <libgen.h>

/*****

Movie struct
Code inspired from Module 1 Exploration: Arrays and Structures
and from https://replit.com/@cs344/studentsc#main.c
Taken from Assignment 1 program 

******/
struct movie {
    char* movie_year;
    char* language;
    char* movie_title;
    char* movie_rating;
    struct movie* next;
};


/*****

Function to allocate memory and make new entries for movies. 
Uses tokens to store data in movie struct.
Pointer usage with help from Module 1 Exploration: Pointers,
    as well as from https://replit.com/@cs344/studentsc#main.c 
This function is similar to the one from Assignment 1

*****/
struct movie* make_movie(char* curr) {
    struct movie* current = malloc(sizeof(struct movie));   // Allocating memory
    char* pointer;         // Creating variables needed for code below
    //char* string;
    //int copy;
    char* movie_token = strtok_r(curr, ",", &pointer);

    // Movie title
    current->movie_title = calloc(strlen(movie_token) + 1, sizeof(char));
    strcpy(current->movie_title, movie_token);


    // Movie year 
    movie_token = strtok_r(NULL, ",", &pointer);
    current->movie_year = calloc(strlen(movie_token) + 1, sizeof(char));
    strcpy(current -> movie_year, movie_token);


    // Movie language
    movie_token = strtok_r(NULL, ",", &pointer);
    current->language = calloc(strlen(movie_token) + 1, sizeof(char));
    strcpy(current->language, movie_token);


    // Movie rating
    movie_token = strtok_r(NULL, "\n", &pointer);
    current->movie_rating = calloc(strlen(movie_token) + 1, sizeof(char));
    strcpy(current->movie_rating, movie_token);

    current->next = NULL;
    return current;
}



/*****

Function to read file, in this case, the given .csv file
Uses a linked list
Code ispired from https://replit.com/@cs344/studentsc#main.c
Taken from Assignment 1 program

*****/
struct movie* readFile(char* movie_file) {
    FILE* mov_file = fopen(movie_file, "r");    // Opening file for read only
    char* temp = NULL;
    char* name;
    // Unsigned type
    size_t len = 0;
    // Signed type
    ssize_t read_file;
    int num = 0;
    struct movie* head = NULL;    
    struct movie* tail = NULL;

    while((read_file = getline(&temp, &len, mov_file)) != -1)      // Reading file line by line
    {
        num++;
        if(num == 1) 
            continue;

        struct movie* nnode = make_movie(temp);      // Making a new node

        if(head == NULL) {
            head = nnode;
            tail = nnode;
        }

        else {
            tail -> next = nnode;
            tail = nnode;
        }
    }

    name = basename(movie_file);
    // Freeing memory and closing file
    free(temp);
    fclose(mov_file);

    return head;
}




/*****

Creating a new directory

*****/
void make_directory(char* movie_data) {
    srand(time(0));
    int num = (random() % 100000);      // Creating random file number
    char file_name[] = "levyca.movies.";   // File name/preix using ONID
    char x[5];
    sprintf(x, "%d", num);
    char name[256];
    
    strcpy(name, file_name);
    strcat(name, x);

    int new_dir = mkdir(name, 0750);          // Making new directory
    printf("Created directory with name %s\n", name);
    char y[256];
    strcpy(y, "./");
    strcat(y, movie_data);
    struct movie *new_list = readFile(y);     // Linked list
    while(new_list != NULL) {
        char new[256];
        char slash[] = "/";
        char ext[] = ".txt";
        strcpy(new, name);
        strcat(new, slash);
        strcat(new, new_list -> movie_year);
        strcat(new, ext);

        FILE *fp = fopen(new, "a");
        char new_string[100];

        strcpy(new_string, new_list->movie_title);
        strcat(new_string, "\n");
        fprintf(fp, new_string);

        fclose(fp);
        if (chmod(new, 0640) != 0)    // Setting file permission
        {
            printf("ERROR: There was a problem creating the new file %s\n", new);
        }

        new_list = new_list -> next;

    }

    struct movie *copy;

    while(new_list != NULL) {
        copy = new_list;
        new_list = new_list -> next;
        free(copy -> movie_title);
        free(copy -> movie_rating);
        free(copy -> language);
        free(copy -> movie_year);
        free(copy);
    }


}


/*****

Struct to find the largest file
Some code inspired from  https://www.youtube.com/watch?v=seZQ21DhJMo
   and https://stackoverflow.com/questions/22160807/file-d-name-into-a-variable-in-c

 
*****/
void find_largest () {
    DIR* direct;
    direct = opendir(".");
    int size = 0;
    char* largest;

    struct dirent* pointer;
    struct stat data;

    // Variables for file name and extension then running through all file entries
    char prefix[] = "movies_";
    char ext[] = ".csv";
    
    while((pointer = readdir(direct)) != NULL) {
        if(strncmp(prefix, pointer -> d_name, strlen(prefix)) == 0) {
            char dot = '.';
            const char *string = (pointer->d_name);    
            char* file_ext = strrchr(string, dot);

            if(file_ext != NULL) 
            {
                if(strcmp(file_ext, ext) == 0) {
                    stat(pointer -> d_name, &data);

                    if(data.st_size > size)      // Comparison to find largest
                    {
                        size = (data.st_size);
                        largest = (pointer -> d_name);
                    }
                }
            }
        }
    }    
    printf("Now processing the chosen file named %s\n", largest);
    make_directory(largest);
    closedir(direct);
    //return largest;
    
}



/*****

Function to find the smallest file
Some code inspired from  https://www.youtube.com/watch?v=seZQ21DhJMo
   and https://stackoverflow.com/questions/22160807/file-d-name-into-a-variable-in-c
Similar to the largest_file() function above


*****/
void find_smallest() {
    DIR* direct;
    direct = opendir(".");
    int size = INT_MAX;
    char* smallest;

    struct dirent* pointer;
    struct stat data;

    // Variables for file name and extension then running through all file entries
    char prefix[] = "movies_";
    char ext[] = ".csv";
    
    while((pointer = readdir(direct)) != NULL) {
        if(strncmp(prefix, pointer -> d_name, strlen(prefix)) == 0) {
            char dot = '.';
            const char *string = (pointer->d_name);
            char* file_ext = strrchr(string, dot);

            if(file_ext != NULL) 
            {
                if(strcmp(file_ext, ext) == 0) {
                    stat(pointer -> d_name, &data);

                    if(data.st_size < size)    // Comparison to find smallest
                    {
                        size = (data.st_size);
                        smallest = (pointer -> d_name);
                    }
                }
            }
        }
    }    
    printf("Now processing the chosen file named %s\n", smallest);
    make_directory(smallest);
    closedir(direct);
    //return smallest;
      
}


/*****

Function to specify the file the user wants to open
Help with running through file entries: https://pubs.opengroup.org/onlinepubs/007904875/functions/readdir_r.html

*****/
bool specific_file() {
    //int check = 0;
    bool validate = false;
    char input[256];
    input[strcspn(input, "\n")] = 0;
    struct dirent* file; 

    printf("Please enter the proper file name: ");
    scanf("%s", input);
    input[strcspn(input, "\n")] = 0;
    struct stat data;
    char* dir = NULL;
    DIR* direct;
    direct = opendir(".");
 
    while((file = readdir(direct)) != NULL) {     // Running through all file entries, used from above functions
        if (strcmp(input, file -> d_name) == 0) 
        {
            stat(file -> d_name, &data);
            dir = (file -> d_name);
        }
    }

        if (validate == false || dir == NULL) {
            printf("ERROR: The file '%s' was not found.", input);
            return file = NULL;
        }

        else
        printf("Now processing the chosen file name '%s' ", input);

        make_directory(dir);
        closedir(direct);
        //return;
}


/*****

Function for sub menu for user input/program usage
Similar to menu for Assignment 1 with modifications made where needed.

*****/
int main(int argc, char *argv[]) {
    //char* copy;
    //struct dirent* file_1;
    //struct dirent* file_2;
    //struct dirent* file_3;
    bool end = false;
    bool menu = true;
    int user_input = 0;
    int user_input2 = 0;
    char str_input[5];
    while(menu) {
        printf("\n------------ Movie Files Program ------------\n");
        printf("\nPlease select an option from the list below by entering the corresponding number and pressing 'ENTER': \n");
        printf("\n1. Select file to process. \n");
        printf("\n2. Exit Program. \n");

        int validate = scanf("%d", &user_input);

        switch(user_input) {
            case 1: {
                bool menu2 = true;
                while(menu) {
                    printf("\n-------------------------------\n");
                    // printf("\nPlease select an option from the list below by entering the corresponding number and pressing 'ENTER': \n"); 
                    printf("\n1. Select the largest file. \n");
                    printf("\n2. Select the smallest file. \n");
                    printf("\n3. Specify the file name. \n");
                    printf("\n4. Exit the program.\n");
                    int validate2 = scanf("%d", &user_input2);
                    switch(user_input2) {
                        case 1:
                            find_largest();
                            menu2 = false;
                            break;

                        case 2:
                            find_smallest();
                            menu2 = false;
                            break;

                        case 3:
                            specific_file();
                            menu2 = false;
                            break;

                        case 4:
                            printf("Exiting...\n");
                            exit(0);

                        default:
                            printf("ERROR: Invalid entry. Please enter only a number from the given options.\n");
                            break;
                        }
                    }
                }

                break;
            
            case 2:
                printf("Exiting...\n");
                exit(0);


            default:
                printf("ERROR: Invalid entry. Please enter only a number from the given options.\n");
                break;
        }
    }

}