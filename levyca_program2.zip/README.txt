Below are the commands to run the Movie program:
To Compile: gcc --std=gnu99 -o movies_by_year files_main.c
To Run: ./movies_by_year