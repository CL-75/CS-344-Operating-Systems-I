/*******************************
Name: Casey Levy
CS 344 - Assignment 5 - One-Time Pads
Description: dec_server.c file
Code cited from:
https://replit.com/@cs344/83serverc?lite=true#server.c
********************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/stat.h>

// Error function used for reporting issues
void error(const char *msg) {
  perror(msg);
  exit(1);
} 


char get_ints(int l)
{
  char* letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ ";
  return letters[l];        // Returning position
}


int get_letters(char l){
  // Getting letters for decryption
  char* letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ ";

  for(int x = 0; x < 27; x++)
  {
    if(letters[x] == l)     // Traversing array of letters
    {
      return x;            // Returning letter in l
    }
  }

  return -1;      // If character is not in letter array

}

void text_decrypt(char deciph[], char main_text[], char main_key[])    // Decrypting text
{
  memset(deciph, '\0', 72456);
  int int_text = 0, int_key = 0, int_deciph = 0;
  int txt_len = strlen(main_text) - 1;       // Setting the text length
  for(int x = 0; x < txt_len; x++)
  {
    int_text = get_letters(main_text[x]);
    int_key = get_letters(main_key[x]);

    int_deciph = (int_text + int_key) % 27;

    if(int_deciph < 0)
      int_deciph += 27;      // Handling if result is less than 0

    deciph[x] = get_ints(int_deciph);
  }

}


// Set up the address struct for the server socket
void setupAddressStruct(struct sockaddr_in* address, 
                        int portNumber){
 
  // Clear out the address struct
  memset((char*) address, '\0', sizeof(*address)); 

  // The address should be network capable
  address->sin_family = AF_INET;
  // Store the port number
  address->sin_port = htons(portNumber);
  // Allow a client at any address to connect to this server
  address->sin_addr.s_addr = INADDR_ANY;
}

int main(int argc, char *argv[]){
  int connectionSocket, charsRead;
  struct sockaddr_in serverAddress, clientAddress;
  socklen_t sizeOfClientInfo = sizeof(clientAddress);

  char main_key[72456];
  char main_text[72456];
  pid_t pid;
  int send_authorize, read_authorize;
  char authorize[2];
  char buff[72456];
  char deciph[72456];


  // Check usage & args
  if (argc < 2) { 
    fprintf(stderr,"USAGE: %s port\n", argv[0]); 
    exit(1);
  } 
  
  // Create the socket that will listen for connections
  int listenSocket = socket(AF_INET, SOCK_STREAM, 0);
  if (listenSocket < 0) {
    error("ERROR opening socket");
  }

    // Set up the address struct for the server socket
  setupAddressStruct(&serverAddress, atoi(argv[1]));

  // Associate the socket to the port
  if (bind(listenSocket, 
          (struct sockaddr *)&serverAddress, 
          sizeof(serverAddress)) < 0){
    error("ERROR on binding");
  }

  // Start listening for connetions. Allow up to 5 connections to queue up
  listen(listenSocket, 5); 
  
  // Accept a connection, blocking if one is not available until one connects
  while(1){
    // Accept the connection request which creates a connection socket
    connectionSocket = accept(listenSocket, 
                (struct sockaddr *)&clientAddress, 
                &sizeOfClientInfo); 
    if (connectionSocket < 0){
      error("ERROR on accept");
    }

	/* memset(buff, '\0', 140000);
	charsRead = recv(connectionSocket, buff, 140000 - 1, 0);
	if(charsRead < 0) 
	{
		error("ERROR reading from socket");
	}
  */

  pid = fork();       // Creating child
    switch(pid)
    {
      case -1:
        perror("fork() has failed!\n");
        exit(1);
        break;

      case 0:
        memset(authorize, '\0', sizeof(authorize));        // Authenticating the server
        read_authorize = recv(connectionSocket, authorize, sizeof(authorize), 0);

        if (read_authorize < 0)
        {
          error("ERROR reading from socket");
        }

        if(strcmp(authorize, "d") != 0)         // Signalling the client is not dec_client for error handling
        {
          strcpy(authorize, "n");
          send_authorize = send(connectionSocket, authorize, sizeof(authorize), 0);
          if (send_authorize < 0)
          {
            error("ERROR writing to socket");
          }
        }

        else
        {
          strcpy(authorize, "y");              // Signalling the client is dec_client
          send_authorize = send(connectionSocket, authorize, sizeof(authorize), 0);

          if(send_authorize < 0)
          {
            error("ERROR writing to socket");
          }
        }

        memset(main_text, '\0', 72456);
        memset(main_key, '\0', 72456);

        charsRead = recv(connectionSocket, main_text, 72456, 0);    // Receiving client's message, reading from socket

        if(charsRead < 0)
        {
          error("ERROR reading from socket");
        }

        charsRead = recv(connectionSocket, main_key, 72456, 0);    // Reading client's msg from socket

        if(charsRead < 0)
        {
          error("ERROR reading from socket");
        }

        text_decrypt(deciph, main_text, main_key);
	      charsRead = send(connectionSocket, deciph, sizeof(deciph), 0);     // Success message
        if (charsRead < 0)
        {
          error("ERROR writing to socket");
        }

        // Close the connection socket for this client
        close(connectionSocket);
        exit(0);
      default:         // Waiting for child to end
        wait(NULL);
        break;

    } 

  }
  // Close the listening socket
  close(listenSocket); 
  return 0;
}
