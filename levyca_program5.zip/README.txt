Below are the commands to run the One Time Pads program:

To Compile: compileall

To Run:  ./p5testscript PORT_NUM1 PORT_NUM2 > mytestresults 2>&1

PORT_NUM1 and PORT_NUM2 need to each be a random number between 55000 and 65000

A file named "mytestresults" will be created with the aforementioned test results created from the
p5testscript file.  