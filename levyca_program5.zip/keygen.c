/*******************************
Name: Casey Levy
CS 344 - Assignment 5 - One-Time Pads
Description: keygen.c file
********************************/

#include <string.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <time.h>

int main(int argc, char *argv[]) {
	if(argc < 2)
	{
		fprintf(stderr, "ERROR: Need argument for key-length\n");
		return 0;
	}
	srand(time(0));

	int key = atoi(argv[1]);
	for(int x = 0; x < key; x++)
	{
		char letter = "ABCDEFGHIJKLMNOPQRSTUVWXYZ "[random() % 27];
		fprintf(stdout, "%c", letter);     // Getting random letter from alphabet range
	} 

	fprintf(stdout, "\n");
	return 0;
}