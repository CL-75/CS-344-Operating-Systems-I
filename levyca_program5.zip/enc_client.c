/*******************************
Name: Casey Levy
CS 344 - Assignment 5 - One-Time Pads
Description: enc_client.c file
Code cited from:
https://replit.com/@cs344/83clientc?lite=true#client.c
********************************/

#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <ctype.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/stat.h>
#include <sys/wait.h>
#include <netdb.h>
#include <netinet/in.h>


/**
* Client code
* 1. Create a socket and connect to the server specified in the command arugments.
* 2. Prompt the user for input and send that input as a message to the server.
* 3. Print the message received from the server and exit the program.
*/

// Error function used for reporting issues
void error(const char *msg) { 
  perror(msg); 
  exit(1); 
} 

// Set up the address struct
void setupAddressStruct(struct sockaddr_in* address, 
                        int portNumber){
 
  // Clear out the address struct
  memset((char*) address, '\0', sizeof(*address)); 

  // The address should be network capable
  address->sin_family = AF_INET;
  // Store the port number
  address->sin_port = htons(portNumber);

  // Get the DNS entry for this host name
  struct hostent* hostInfo = gethostbyname("localhost"); 
  if (hostInfo == NULL) { 
    fprintf(stderr, "CLIENT: ERROR, no such host\n"); 
    exit(0); 
  }
  // Copy the first IP address from the DNS entry to sin_addr.s_addr
  memcpy((char*) &address->sin_addr.s_addr, 
        hostInfo->h_addr_list[0],
        hostInfo->h_length);
}

int main(int argc, char *argv[]) {
  int socketFD, portNumber, charsWritten, charsRead;
  struct sockaddr_in serverAddress;
  char authorize[2] = "e";             // for encrypt
  FILE* file;
  char buff[72456];                   // Creating buffer
  int send_authorize, read_authorize, bytes;

  memset(buff, '\0', sizeof(buff));


// Check usage & args
  if (argc != 4) 
  { 
    fprintf(stderr,"ERROR: Incorrect number of arguments\n"); 
  } 


  // Create a socket
  socketFD = socket(AF_INET, SOCK_STREAM, 0); 
  if (socketFD < 0){
    error("CLIENT: ERROR opening socket");
  }

   // Set up the server address struct
  setupAddressStruct(&serverAddress, atoi(argv[3]));

  // Connect to server
  if (connect(socketFD, (struct sockaddr*)&serverAddress, sizeof(serverAddress)) < 0){
    error("CLIENT: ERROR connecting");
  }

  // Opening files
  // https://www.kernel.org/doc/htmldocs/kernel-api/API-ksize.html#:~:text=ksize%20%E2%80%94%20get%20the%20actual%20amount%20of%20memory%20allocated%20for%20a%20given%20object
  int main_key = open(argv[2], O_RDONLY);
  int kSize = lseek(main_key, 0, SEEK_END);   // getting the actual amount of memory allocated for the given object
  int text = open(argv[1], O_RDONLY);
  int size = lseek(text, 0, SEEK_END);

  if(size > kSize)                 // Checking to ensure main_key file is large enough
  {
    fprintf(stderr, "ERROR: Given key is too short!\n");
  }

  while(read(text, buff, 1) != 0)
  {
    if(!(isspace(buff[0]) || isalpha(buff[0])))    // https://www.pitt.edu/~naraehan/python3/string_methods2.html
    {
      fprintf(stderr, "ERROR: Invalid character found in %s\n", argv[1]);
      exit(1);               // Exiting if invalid characters are found
    }
  }

  // Send message to server
  // Write to the server
  send_authorize = send(socketFD, authorize, sizeof(authorize), 0); 
  if (send_authorize < 0){
    error("CLIENT: ERROR writing to socket");
  }

  memset(authorize, '\0', sizeof(authorize));

  read_authorize = recv(socketFD, authorize, sizeof(authorize), 0);

  if(read_authorize < 0)
  {
    error("CLIENT: ERROR Reading from Socket");
  }

  if(strcmp(authorize, "y") != 0)    // If valid
  {
    error("ERROR: Connected client not dec_client");
  }
  
  file = fopen(argv[1], "r");          // Sending files to the server
  memset(buff, '\0', sizeof(buff));

  while((size = fread(buff, sizeof(char), 72456, file)) > 0)
  {
    if((bytes = send(socketFD, buff, size, 0)) < 0)
    {
      error("CLIENT: Error writing to socket: 2");
      break;
    }

    memset(buff, '\0', sizeof(buff));
  }

  fclose(file);

  file = fopen(argv[2], "r");           // Opening the key file
  memset(buff, '\0', sizeof(buff));

  while((kSize = fread(buff, sizeof(char), 72456, file)) > 0)
  {
    if((bytes = send(socketFD, buff, kSize, 0)) < 0)
    {
      error("CLIENT: Error writing to socket: 3");
      break;
    }

    memset(buff, '\0', sizeof(buff));
  }

  fclose(file);


  // Get return message from server
  memset(buff, '\0', sizeof(buff));

  // Read data from the socket, leaving \0 at end
  charsRead = recv(socketFD, buff, sizeof(buff) - 1, 0); 
  if (charsRead < 0)
  {
      error("CLIENT: ERROR reading from socket");
  }


  // printf("CLIENT: I received this from the server: \"%s\"\n", buff);

  fprintf(stdout, "%s\n", buff);
  fflush(stdout);       // Flushing out buffer

  // Close the socket
  close(socketFD); 
  return 0;
}