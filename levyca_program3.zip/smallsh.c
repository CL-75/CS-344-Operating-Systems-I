/**********************

Name: Casey Levy
Info: CS 344 - Assignment 3 - smallsh
Program Description: Creating our own shell
Code referred to/cited from the following links:

https://www.cs.cornell.edu/courses/cs414/2004su/homework/shell/shell.html
https://brennan.io/2015/01/16/write-a-shell-in-c/
https://indradhanush.github.io/blog/writing-a-unix-shell-part-1/

Assignment 3 Canvas page
https://canvas.oregonstate.edu/courses/1810930/assignments/8336390?module_item_id=20734161

***********************/

#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <unistd.h>
#include <signal.h>

// Globals
int bg = 1;
#define INPUT_LEN 2048

// Functions
void input(char*[], int*, char[], char[], int);
void print_exit(int);
void command(char*[], int*, struct sigaction, int*, char[], char[]);
void catch_SIGTSTP(int);


/**********
 
 Main Function

**********/
int main() {

	int exit_stat = 0;
	int backg = 0;
	char file_input[256];
	char file_output[256];
	char *user_input[512];
	int x;
	int count = 1;
	int sh_pid = getpid();

	for(x = 0; x < 512; x++)
		user_input[x] = NULL;

	// Signal Handlers 
	// Creating and initializing the SIGINT for the command ^C
	struct sigaction SIGINT_action = {0};
	SIGINT_action.sa_handler = SIG_IGN;
	sigfillset(&SIGINT_action.sa_mask);
	SIGINT_action.sa_flags = 0;
	sigaction(SIGINT, &SIGINT_action, NULL);

	// Creating and initializing the SIGTSTP for the command ^Z
	struct sigaction SIGTSTP_action = {0};
	SIGTSTP_action.sa_handler = catch_SIGTSTP;
	sigfillset(&SIGTSTP_action.sa_mask);
	SIGTSTP_action.sa_flags = 0;
	sigaction(SIGTSTP, &SIGTSTP_action, NULL);

	do
	{
		// Getting user input
		input(user_input, &backg, file_input, file_output, sh_pid);

		if(user_input[0][0] == '#' || user_input[0][0] == '\0')  // If command line has a comment or is left blank
			continue;

		else if(strcmp(user_input[0], "status") == 0)    // If user input is "status"
			print_exit(exit_stat);

		else if(strcmp(user_input[0], "cd") == 0)        // If user input is "cd"
		{
			if(user_input[1])   // Moving to desired directory
			{
				if(chdir(user_input[1]) == -1)
				{
					printf("\nERROR: Directory not found.\n");
					fflush(stdout);           // Printing error and flushing buffer
				}
			}
			
			else
				chdir(getenv("HOME"));     // Auto-directs to home directory if one is not specified
		}

		else if(strcmp(user_input[0], "exit") == 0)    // If user input is "exit"
			count = 0;

		else  // If any other command/input is given
			command(user_input, &exit_stat, SIGINT_action, &backg, file_input, file_output);

		for(x = 0; user_input[x]; x++)    // Resetting
			user_input[x] = NULL;

		file_output[0] = '\0';
		file_input[0] = '\0';
		backg = 0;
	}

	while(count);
	return 0;
}



/***************

Prompting and getting user input as well
as parsing input into an array.

***************/
void input(char *array[], int *backg, char in_name[], char out_name[], int sh_pid) {
	int x, y;
	char user_input[INPUT_LEN];
	printf(": ");        // Printing command line
	fflush(stdout);     // Flushing buffer
	fgets(user_input, INPUT_LEN, stdin);   // Getting user input
	int temp = 0;

	for(x = 0; !temp && x < INPUT_LEN; x++)    // Remvoing newline
	{
		if(user_input[x] == '\n')
		{
			user_input[x] = '\0';
			temp = 1;
		}
	}

	if(!strcmp(user_input, ""))  // Returning blank line if one is entered
	{
		// https://man7.org/linux/man-pages/man3/strdup.3.html#:~:text=The%20strdup()%20function%20returns,copies%20at%20most%20n%20bytes.
		array[0] = strdup("");  
		return;
	}

	const char line_space[2] = " ";
	char* input_token = strtok(user_input, line_space);
	for(x = 0; input_token; x++)
	{
		if(!strcmp(input_token, ">"))   // If ">" is entered, this denotes an output file
		{
			input_token = strtok(NULL, line_space);
			strcpy(out_name, input_token);
		}

		else if(!strcmp(input_token, "<"))  // If "<" is entered, this denotes an input file
		{
			input_token = strtok(NULL, line_space);
			strcpy(in_name, input_token);
		}

		else if(!strcmp(input_token, "&"))   // If "&" is entered, checks for a background process
			*backg = 1;

		else    // Any other input apart of the command
		{
			array[x] = strdup(input_token);
			for(y = 0; array[x][y]; y++)
			{
				if(array[x][y] == '$' && array[x][y] == '$')
				{
					array[x][y] = '\0';
					snprintf(array[x], 256, "%s%d", array[x], sh_pid);
				}
			}
		}

		input_token = strtok(NULL, line_space);
	}
}



/***************

Performs the command entered and 
parsed into an array
Code inspired from https://www.youtube.com/watch?v=1R9h-H2UnLs&t=222s

***************/
void command(char *array[], int* child_exit, struct sigaction sig_a, int *backg, char in_name[], char out_name[]) {
	pid_t spawn_pid = -5;
	int user_input;
	int user_output;
	int res;

	// https://www.youtube.com/watch?v=1R9h-H2UnLs&t=222s from timestamp 41:30
	spawn_pid = fork();

	switch(spawn_pid)
	{
		case -1:
			perror("Hull breach!\n");
			exit(1);
			break;

		case 0:
			sig_a.sa_handler = SIG_DFL;     // Taking ^C as default
			sigaction(SIGINT, &sig_a, NULL);
			if(strcmp(in_name, ""))     // https://www.youtube.com/watch?v=9Gsp-wucTNw
			{
				user_input = open(in_name, O_RDONLY);    // Handling and opening input
				if(user_input == -1)
				{
					perror("ERROR: Unable to open input file.\n");
					exit(1);
				}

				res = dup2(user_input, 0);    // Assigning
				if(res == -1)
				{
					perror("ERROR: Unable to assign input file.\n");
					exit(2);
				}

				fcntl(user_input, F_SETFD, FD_CLOEXEC);
			}

			if(strcmp(out_name, ""))     // Handling output
			{
				user_output = open(out_name, O_WRONLY | O_CREAT | O_TRUNC, 0666);
				if(user_output == -1)
				{
					perror("ERROR: Unable to open output file\n");
					exit(1);
				}

				res = dup2(user_output, 1);      // Assigning
				if(res == -1)
				{
					perror("ERROR: Unable to assign output file\n");
					exit(2);
				}

				fcntl(user_output, F_SETFD, FD_CLOEXEC);     // Close
			}

			if(execvp(array[0], (char* const*)array))      // Executing
			{
				printf("%s: No such file or directory\n", array[0]);
				fflush(stdout);
				exit(2);
			}

			break;
		default:	;
			if(bg && *backg)
			{
				pid_t pid = waitpid(spawn_pid, child_exit, WNOHANG);    // If backg is true, execute a process in the background only
				printf("background pid is %d\n", spawn_pid);
				fflush(stdout);       // Flushing buffer
			}

			else {
				pid_t pid = waitpid(spawn_pid, child_exit, 0);
			}

		while((spawn_pid = waitpid(-1, child_exit, WNOHANG)) > 0)    // Checking for any terminated backg processes
		{
			printf("child %d terminated\n", spawn_pid);
			print_exit(*child_exit);
			fflush(stdout);       // Flushing buffer
		}
	}
}



/***************

Background bool (bg) activated when
SIGTSTP is called.

***************/
void catch_SIGTSTP(int signo) {
	if(bg == 1)        // If 1, set to 0 and display confirmation message
	{
		char* msg = "Entering foreground-only mode ('&' is now ignored)\n";
		write(1, msg, 49);
		fflush(stdout);
		bg = 0;
	}

	else         // If 0, set to 1 and display confirmation message
	{
		char *msg = "Exiting foreground-only mode\n";
		write(1, msg, 29);
		fflush(stdout);
		bg = 1;
	}
}



/***************

Calling the exit status

***************/
void print_exit(int child_exit) {            // If exiting by status or terminated by signal
	if(WIFEXITED(child_exit))
		printf("exit value %d\n", WEXITSTATUS(child_exit));     

	else
		printf("terminated by signal %d\n", WTERMSIG(child_exit));
}