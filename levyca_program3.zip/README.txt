Below are the commands to run the smallsh program:
To Compile: gcc --std=gnu99 -o smallsh smallsh.c
To Run: ./smallsh