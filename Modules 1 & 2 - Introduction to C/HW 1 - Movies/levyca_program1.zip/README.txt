### Compile and run commands cited from Canvas page - "Assignment 1 - Movies" ###

Below are the commands to run the Movie program:
To Compile: gcc --std=gnu99 -o movies movies_main.c
To Run: ./movies movies_sample_1.csv